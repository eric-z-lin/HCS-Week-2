# HCS-Week-2
### Week 2 Comp of Harvard Computer Society.

Program that uses K Nearest Neighbors to classify students into different colleges based on GPA and SAT scores.
Team Members: Eric Lin, Anna Wang, Max Bobby